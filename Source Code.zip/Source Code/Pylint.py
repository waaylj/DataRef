import os
import re
import chardet
import subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import traceback

# 常量配置
TEMP_DIR = Path("temp_pylint")  # 临时文件目录
MAX_WORKERS = 4  # 并行线程数


def detect_file_encoding(file_path: str) -> str:
    """使用 chardet 自动检测文件编码"""
    try:
        with open(file_path, "rb") as f:
            raw_data = f.read(5000)  # 读取前5000字节用于检测
        result = chardet.detect(raw_data)
        return result["encoding"] or "utf-8"
    except Exception as e:
        print(f"编码检测失败 [{file_path}]: {str(e)}")
        return "utf-8"


def read_file_with_auto_encoding(file_path: str) -> str:
    """自动识别编码读取文件内容"""
    encoding = detect_file_encoding(file_path)
    try:
        with open(file_path, "r", encoding=encoding, errors="replace") as f:
            return f.read()
    except UnicodeDecodeError:
        # 回退到 utf-8 并忽略错误
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()


def extract_pylint_score(output: str) -> float:
    """从 Pylint 输出中提取评分"""
    match = re.search(r"rated at (\d+\.?\d*)/10", output)
    return float(match.group(1)) if match else 0.0


def process_single_file(file_path: str) -> float:
    """处理单个文件的完整流程"""
    try:
        # 创建临时目录
        TEMP_DIR.mkdir(exist_ok=True)

        # 生成唯一临时文件名
        file_name = Path(file_path).name
        temp_file = TEMP_DIR / f"{file_name}_temp.py"

        # 读取并重新写入UTF-8编码文件
        content = read_file_with_auto_encoding(file_path)
        with open(temp_file, "w", encoding="utf-8") as f:
            f.write(content)

        # 运行 Pylint
        result = subprocess.run(
            ["pylint", str(temp_file)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            env={**os.environ, "PYTHONIOENCODING": "utf-8"}
        )

        # 清理临时文件
        temp_file.unlink(missing_ok=True)

        return extract_pylint_score(result.stdout)
    except Exception as e:
        print(f"处理文件 {file_path} 时出错:")
        traceback.print_exc()
        return 0.0


def main():
    # 获取文件列表
    code_dir = Path("code")
    txt_files = [str(file) for file in code_dir.glob("*.txt")]

    # 并行处理
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        scores = list(executor.map(process_single_file, txt_files))

    # 输出结果
    total_score = sum(scores)
    avg_score = total_score / len(scores) if scores else 0

    print("\n各文件得分:")
    for file, score in zip(txt_files, scores):
        print(f"- {Path(file).name}: {score:.2f}/10")

    print(f"\n平均 Pylint 得分: {avg_score:.2f}/10")

    # 清理临时目录
    for temp_file in TEMP_DIR.glob("*_temp.py"):
        temp_file.unlink()
    TEMP_DIR.rmdir()


if __name__ == "__main__":
    main()