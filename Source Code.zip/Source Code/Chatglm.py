

from langchain_community.chat_models import ChatZhipuAI
from langchain.schema import HumanMessage
def get_answer(ques):
    zhipuai_chat = ChatZhipuAI(
        temperature=0.1,
        max_tokens=2048,
        api_key="",
        model="codegeex-4"
    )
    msg = [HumanMessage(content=ques)]
    ans = zhipuai_chat(msg)
    return ans.content


