import os
import chardet
def count_code_lines_in_file(file_path):
    """
    计算文件中 Python 代码行数，忽略空行和注释行
    """
    with open(file_path, 'rb') as file:
        raw_data = file.read()
        result = chardet.detect(raw_data)
        file_encoding = result['encoding']
        print(f"Detected file encoding: {file_encoding}")
    with open(file_path, 'r', encoding=file_encoding) as f:
        code_lines = 0
        for line in f:
            # 忽略空行和注释行
            stripped_line = line.strip()
            if stripped_line:
                code_lines += 1
        return code_lines

def calculate_average_code_lines(directory):
    """
    计算指定目录下所有 .txt 文件中的 Python 代码的平均行数
    """
    total_lines = 0
    total_files = 0

    for filename in os.listdir(directory):
        if filename.endswith(".txt"):
            file_path = os.path.join(directory, filename)
            lines_in_file = count_code_lines_in_file(file_path)
            total_lines += lines_in_file
            total_files += 1

    if total_files == 0:
        return 0  # 如果没有 txt 文件，返回 025
    return total_lines / total_files

# 使用例子
directory_path = './after'  # 替换为包含 txt 文件的目录路径
average_lines = calculate_average_code_lines(directory_path)
print(f"所有 .txt 文件的平均代码行数: {average_lines:.2f}")
