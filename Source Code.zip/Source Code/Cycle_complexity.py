import os
import radon.complexity as complexity
import chardet

def get_cyclomatic_complexity(file_path):
    """计算单个文件的圈复杂度"""
    with open(file_path, 'rb') as file:
        raw_data = file.read()
        result = chardet.detect(raw_data)
        file_encoding = result['encoding']
        print(f"Detected file encoding: {file_encoding}")
    with open(file_path, 'r',encoding=file_encoding) as file:
        code = file.read()

    # 使用 Radon 获取代码的圈复杂度
    try:
        blocks = complexity.cc_visit(code)  # 返回一个包含所有代码块复杂度的列表
        total_complexity = sum(block.complexity for block in blocks)  # 计算所有代码块复杂度的总和
        return total_complexity
    except Exception as e:
        print(f"无法处理文件 {file_path}，错误: {e}")
        return 0


def calculate_average_complexity(directory_path):
    """计算指定目录中所有 Python 文件（.txt 格式）的平均圈复杂度"""
    total_complexity = 0
    total_files = 0

    # 遍历目录中的所有 .txt 文件
    for root, dirs, files in os.walk(directory_path):
        for file in files:
            if file.endswith(".txt"):  # 识别 .txt 文件
                file_path = os.path.join(root, file)
                print(f"计算文件: {file_path}")
                complexity_value = get_cyclomatic_complexity(file_path)
                print(complexity_value)
                if complexity_value > 0:
                    total_complexity += complexity_value
                    total_files += 1

    # 计算平均复杂度
    if total_files > 0:
        average_complexity = total_complexity / total_files
        print(f"\n平均圈复杂度: {average_complexity:.2f}")
    else:
        print("没有有效的 Python 文件可供计算。")


if __name__ == "__main__":
    directory_path = "./after"  # 替换为实际的 .txt 文件目录路径
    calculate_average_complexity(directory_path)
