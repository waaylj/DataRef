
import os
from langchain_openai import ChatOpenAI
from langchain.schema import HumanMessage
def get_answer(ques):

    os.environ["OPENAI_API_KEY"] = ""
    os.environ["OPENAI_BASE_URL"] = ""
    chat = ChatOpenAI(
        model_name="qwen2.5-72b-instruct",
        temperature=0.0,
        max_tokens=2048,
        top_p=1


    )
    msg = [HumanMessage(content=ques)]
    ans = chat.invoke(msg)
    return ans.content
