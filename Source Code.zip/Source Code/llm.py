
import os
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

def get_answer(ques):

    os.environ["OPENAI_API_KEY"] = "" 
    os.environ["OPENAI_BASE_URL"] = "" 
    chat = ChatOpenAI(
        model_name="gpt-3.5-turbo",#gpt-4-turbo-2024-04-09  gpt-4o gpt-3.5-turbo
        temperature=0.1,
        max_tokens=2048

    )
    msg = [HumanMessage(content=ques)]
    ans = chat.invoke(msg)
    return ans.content
