import os
import chardet
def count_characters_in_file(file_path):
    """
    计算单个文件中的字符数（包括空格和换行符）
    """
    with open(file_path, 'rb') as file:
        raw_data = file.read()
        result = chardet.detect(raw_data)
        file_encoding = result['encoding']
        print(f"Detected file encoding: {file_encoding}")
    with open(file_path, 'r', encoding=file_encoding) as f:
        content = f.read()
        return len(content)

def calculate_average_characters(directory):
    """
    计算指定目录下所有 .txt 文件的平均字符数
    """
    total_characters = 0
    total_files = 0

    for filename in os.listdir(directory):
        if filename.endswith(".txt"):  # 只处理 .txt 文件
            file_path = os.path.join(directory, filename)
            characters_in_file = count_characters_in_file(file_path)
            total_characters += characters_in_file
            total_files += 1

    if total_files == 0:
        return 0  # 如果没有 txt 文件，返回 0
    return total_characters / total_files

# 使用例子
directory_path = './after'  # 替换为包含 txt 文件的目录路径
average_characters = calculate_average_characters(directory_path)
print(f"所有 .txt 文件的平均字符数: {average_characters:.2f}")
