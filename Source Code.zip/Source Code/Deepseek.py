
# * deepseek-chat 模型已全面升级为 DeepSeek-V3，接口不变。 通过指定 model='deepseek-chat' 即可调用 DeepSeek-V3。
# * deepseek-reasoner 是 DeepSeek 最新推出的推理模型 DeepSeek-R1。通过指定 model='deepseek-reasoner'，即可调用 DeepSeek-R1。


import os
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage
def get_answer(ques):

    os.environ["OPENAI_API_KEY"] = ""
    os.environ["OPENAI_BASE_URL"] = ""
    chat = ChatOpenAI(
        model_name="deepseek-chat",
        temperature=0,
        max_tokens=2048,
        top_p=1

    )
    msg = [HumanMessage(content=ques)]
    ans = chat.invoke(msg)
    return ans.content
