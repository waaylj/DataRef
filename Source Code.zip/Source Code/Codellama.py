# https://build.nvidia.com/meta/codellama-70b
import os
from openai import OpenAI
for f in os.listdir("./code"):
    fpath = os.path.join("./code",f)
    code = open(fpath,"r",encoding="utf-8").read()
    question = """
                    You are a senior Python programmer. I will give you a Python file.
                    You need to refactor it to improve the readability of the code.
                    Just give me the refactored code, no need to explain.
                    The input file is
                    ```
                    """ + code + """
                    ```
                """
    file_name = os.path.splitext(os.path.basename(fpath))[0]
    refactor_file_name = """Refactor""" + file_name + """.txt"""
    client = OpenAI(
      base_url="",
      api_key=""
    )

    completion = client.chat.completions.create(
      model="meta/codellama-70b",  # google/codegemma-7b
      messages=[{"role": "user", "content": question}],
      temperature=0.1,
      top_p=1,
      max_tokens=2048,
      stream=True
    )
    with open(os.path.join("E:/pycharm/LLMRefactoring/after", refactor_file_name), "w",encoding='utf-8') as out:
      for chunk in completion:
        if chunk.choices[0].delta.content is not None:
          out.write(chunk.choices[0].delta.content)
    print(f"{refactor_file_name} 重构完成")








