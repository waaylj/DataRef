import os
import llm
# import Chatglm
# import Deepseek
# import Qwen
for f in os.listdir("./code"):
    fpath = os.path.join("./code",f)
    # print(fpath)
    code = open(fpath,"r",encoding="utf-8").read()
    question = """
                        You are a senior Java programmer. I will give you a Java file.
                        You need to refactor it to improve the efficiency of the code.
                        Just give me the refactored code, no need to explain.
                        The input file is
                        ```
                        """ + code + """
                        ```
                    """
    # 思维链提示，在提示词中加入一句话，让我们一步一步来解决问题或let's take this action step by step
    # question = """
    # [角色设定]
    # 您是资深代码重构专家，需要严格遵循以下要求：
    # 1. 保持原始功能不变（输入输出行为零变更）
    # 2. 保留所有边界条件处理
    # 3. 不引入未经验证的外部依赖和新功能
    #
    # [重构步骤]
    # 1️⃣ 语义分析：用中文描述原始代码的核心功能
    # 2️⃣ 约束识别：标注必须保持的代码特征
    # 3️⃣ 优化建议：列出可改进的代码特征（命名/结构/冗余等）
    # 4️⃣ 重构实现：生成优化后的代码
    #
    # [输出要求]
    # 1. 使用Python 3.10+语法
    # 2. 保留原始注释并在修改处添加# CHANGED标记
    # 3. 保持一致的缩进风格
    #
    # [输入代码]
    #                 ```
    #                 """ + code + """
    #                 ```
    #             """
    # 请重构以下代码
    # question = """
    #                     You are a senior Java/Python programmer. I will give you a few Java class files./I will give you a Python file.
    #                     These class files are a parallelizable program.
    #                     You need to refactor it to improve the readability/efficiency of the code.
    #                     With no explanation refactor the Java code to improve its quality and [quality attribute]
    #                     The class  """ + i + """ file is
    #                     ```
    #                     """ + code + """
    #                     ```
    #                 """
    file_name = os.path.splitext(os.path.basename(fpath))[0]
    refactor_file_name = """Refactor""" + file_name + """.txt"""
    # print(refactor_file_name)
    # print(question)
    answer = llm.get_answer(question)
    # answer = Deepseek.get_answer(question)
    with open(os.path.join("E:/pycharm/LLMRefactoring/after", refactor_file_name), "w", encoding="utf-8") as out:
         out.write(answer)
         print(f"{refactor_file_name} 重构完成")
