import ast
import os
import chardet
import numpy as np
from pathlib import Path
from typing import List, Dict
from codebleu import calc_codebleu
import traceback


def detect_encoding(file_path: str) -> str:
    with open(file_path, "rb") as f:
        raw_data = f.read(5000)
    result = chardet.detect(raw_data)
    return result["encoding"] or "utf-8"


def read_code_with_retry(file_path: str) -> str:
    try:
        encoding = detect_encoding(file_path)
        with open(file_path, "r", encoding=encoding, errors="replace") as f:
            content = f.read()
        return content
    except UnicodeDecodeError:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()


def validate_code_syntax(code: str, file_path: str):
    """验证代码是否可解析"""
    try:
        ast.parse(code)
    except SyntaxError as e:
        raise ValueError(f"文件 {file_path} 存在语法错误: {str(e)}")


def calculate_single_codebleu(candidate_path: str, reference_paths: List[str]) -> float:
    try:
        # 读取并验证候选代码
        candidate_code = read_code_with_retry(candidate_path)
        validate_code_syntax(candidate_code, candidate_path)

        # 读取并验证参考代码
        references = []
        for ref_path in reference_paths:
            ref_code = read_code_with_retry(ref_path)
            validate_code_syntax(ref_code, ref_path)
            references.append(ref_code)

        # 计算 CodeBLEU
        result = calc_codebleu(
            [candidate_code],
            references,
            lang="python",
            weights=(0.25, 0.25, 0.25, 0.25),
            tokenizer=None
        )
        return result["codebleu"]
    except Exception as e:
        print(f"处理文件 {candidate_path} 时发生内部错误:")
        traceback.print_exc()
        return 0.0


def get_reference_path(candidate_path: Path, reference_dir: Path) -> Path:
    """处理带 Refactor 前缀的文件名"""
    if candidate_path.name.startswith("Refactor"):
        ref_name = candidate_path.name[len("Refactor"):]
    else:
        ref_name = candidate_path.name
    return reference_dir / ref_name


def main():
    candidate_dir = Path("./after")
    reference_dir = Path("./code")
    candidates = list(candidate_dir.glob("*.txt"))

    score_list = []
    for cand_file in candidates:
        ref_file = get_reference_path(cand_file, reference_dir)

        if not ref_file.exists():
            print(f"警告：参考文件 {ref_file} 不存在，跳过")
            continue

        try:
            score = calculate_single_codebleu(
                str(cand_file),
                [str(ref_file)]
            )
            score_list.append(score)
            print(f"{cand_file.name} -> {ref_file.name}: {score:.4f}")
        except Exception as e:
            print(f"严重错误: {cand_file.name} 处理失败")
            traceback.print_exc()

    if score_list:
        avg_score = np.mean(score_list)
        print(f"\n平均 CodeBLEU 得分: {avg_score:.4f} (有效样本: {len(score_list)})")
    else:
        print("无有效样本可计算")


if __name__ == "__main__":
    main()
# from codebleu import calc_codebleu
#
# # Example: list containing one predicted code and one reference code
# predicted_code = ["def add(a, b):\n    return a + b"]
# reference_code = ["def add_two_numbers(a, b):\n    return a + b"]
#
# # Calculate CodeBLEU score
# score = calc_codebleu(predicted_code, reference_code,lang="python")
#
# # Output the result
# print("CodeBLEU Score:", score)








